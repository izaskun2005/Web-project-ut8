public class Administrador extends Usuario{
}
